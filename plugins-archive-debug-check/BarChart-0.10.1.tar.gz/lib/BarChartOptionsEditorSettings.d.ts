import { ReactElement } from 'react';
import { BarChartOptionsEditorProps } from './bar-chart-model';
export declare function BarChartOptionsEditorSettings(props: BarChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=BarChartOptionsEditorSettings.d.ts.map