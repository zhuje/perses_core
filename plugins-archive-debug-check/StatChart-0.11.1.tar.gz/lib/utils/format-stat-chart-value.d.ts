import { FormatOptions } from '@perses-dev/core';
export declare const formatStatChartValue: (value?: string | number | null, format?: FormatOptions) => string;
//# sourceMappingURL=format-stat-chart-value.d.ts.map