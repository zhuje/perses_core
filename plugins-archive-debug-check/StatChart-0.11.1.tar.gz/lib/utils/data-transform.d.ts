import { PersesChartsTheme } from '@perses-dev/components';
import { LineSeriesOption } from 'echarts/charts';
import { StatChartSparklineOptions } from '../stat-chart-model';
export declare function convertSparkline(chartsTheme: PersesChartsTheme, color: string, sparkline?: StatChartSparklineOptions): LineSeriesOption | undefined;
//# sourceMappingURL=data-transform.d.ts.map