import { PersesChartsTheme } from '@perses-dev/components';
import { StatChartOptions } from '../stat-chart-model';
type StatChartValue = number | string | null;
export declare function getStatChartColor(chartsTheme: PersesChartsTheme, spec?: StatChartOptions, value?: StatChartValue): string;
export {};
//# sourceMappingURL=get-color.d.ts.map