import { ReactElement } from 'react';
import { StatChartOptionsEditorProps } from './stat-chart-model';
export declare function StatChartOptionsEditorSettings(props: StatChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=StatChartOptionsEditorSettings.d.ts.map