export * from './gauge-chart-model';
export * from './GaugeChart';
export * from './GaugeChartOptionsEditorSettings';
export * from './GaugeChartPanel';
export { getPluginModule } from './getPluginModule';
export * from './thresholds';
//# sourceMappingURL=index.d.ts.map