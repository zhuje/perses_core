import { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import { VictoriaLogsTimeSeriesQuerySpec } from './types';
export declare const VictoriaLogsTimeSeriesQuery: TimeSeriesQueryPlugin<VictoriaLogsTimeSeriesQuerySpec>;
//# sourceMappingURL=VictoriaLogsTimeSeriesQuery.d.ts.map