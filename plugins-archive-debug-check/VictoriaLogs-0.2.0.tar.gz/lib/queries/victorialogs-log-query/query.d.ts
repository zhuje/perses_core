import { VictoriaLogsLogQuerySpec } from './types';
import { LogQueryPlugin } from './interface';
export declare const getVictoriaLogsLogData: LogQueryPlugin<VictoriaLogsLogQuerySpec>['getLogData'];
//# sourceMappingURL=query.d.ts.map