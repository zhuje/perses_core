import { VictoriaLogsLogQuerySpec } from './types';
import { LogQueryPlugin } from './interface';
export declare const VictoriaLogsLogQuery: LogQueryPlugin<VictoriaLogsLogQuerySpec>;
//# sourceMappingURL=VictoriaLogsLogQuery.d.ts.map