import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { VictoriaLogsFieldValuesVariableOptions } from '../types';
export declare function VictoriaLogsFieldValuesVariableEditor(props: OptionsEditorProps<VictoriaLogsFieldValuesVariableOptions>): ReactElement;
//# sourceMappingURL=VictoriaLogsFieldValuesVariableEditor.d.ts.map