import { VariablePlugin } from '@perses-dev/plugin-system';
import { VictoriaLogsFieldNamesVariableOptions } from '../types';
export declare const VictoriaLogsFieldNamesVariable: VariablePlugin<VictoriaLogsFieldNamesVariableOptions>;
//# sourceMappingURL=VictoriaLogsFieldNamesVariable.d.ts.map