import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { VictoriaLogsFieldNamesVariableOptions } from '../types';
export declare function VictoriaLogsFieldNamesVariableEditor(props: OptionsEditorProps<VictoriaLogsFieldNamesVariableOptions>): ReactElement;
//# sourceMappingURL=VictoriaLogsFieldNamesVariableEditor.d.ts.map