export * from './victorialogs-datasource';
//# sourceMappingURL=index.d.ts.map