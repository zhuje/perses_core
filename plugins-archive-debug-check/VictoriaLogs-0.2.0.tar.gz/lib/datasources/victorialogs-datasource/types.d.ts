import { HTTPProxy } from '@perses-dev/core';
export interface VictoriaLogsDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
//# sourceMappingURL=types.d.ts.map