export declare const logsqlHighlight: import("@lezer/common").NodePropSource;
//# sourceMappingURL=logsql-highlight.d.ts.map