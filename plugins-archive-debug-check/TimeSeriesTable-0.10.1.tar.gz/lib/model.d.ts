export interface TimeSeriesTableOptions {
}
//# sourceMappingURL=model.d.ts.map