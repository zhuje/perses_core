export * from './CellsEditor';
//# sourceMappingURL=index.d.ts.map