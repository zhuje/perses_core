import { PersesChartsTheme } from '@perses-dev/components';
import { Theme } from '@mui/material';
export declare function getServiceColor(muiTheme: Theme, chartsTheme: PersesChartsTheme, paletteMode: 'auto' | 'categorical' | undefined, serviceName: string, error?: boolean): string;
//# sourceMappingURL=utils.d.ts.map