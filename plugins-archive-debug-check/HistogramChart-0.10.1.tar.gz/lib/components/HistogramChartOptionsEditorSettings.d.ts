import { ReactElement } from 'react';
import { HistogramChartOptionsEditorProps } from '../histogram-chart-model';
export declare function HistogramChartOptionsEditorSettings(props: HistogramChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=HistogramChartOptionsEditorSettings.d.ts.map