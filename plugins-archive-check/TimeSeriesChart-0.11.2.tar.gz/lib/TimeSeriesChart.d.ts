import { PanelPlugin } from '@perses-dev/plugin-system';
import { TimeSeriesChartOptions } from './time-series-chart-model';
import { TimeSeriesChartProps } from './TimeSeriesChartPanel';
export declare const TimeSeriesChart: PanelPlugin<TimeSeriesChartOptions, TimeSeriesChartProps>;
//# sourceMappingURL=TimeSeriesChart.d.ts.map