import { ReactElement } from 'react';
import { TimeSeriesChartOptionsEditorProps } from './time-series-chart-model';
export declare function QuerySettingsEditor(props: TimeSeriesChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=QuerySettingsEditor.d.ts.map