import { ReactElement } from 'react';
import { Span } from '../trace';
import { CustomLinks } from '../../gantt-chart-model';
export interface SpanLinkListProps {
    customLinks?: CustomLinks;
    span: Span;
}
export declare function SpanLinkList(props: SpanLinkListProps): ReactElement;
//# sourceMappingURL=SpanLinks.d.ts.map