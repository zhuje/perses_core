import { ReactElement } from 'react';
import { Trace } from './trace';
export interface TraceDetailsProps {
    trace: Trace;
}
export declare function TraceDetails(props: TraceDetailsProps): ReactElement;
//# sourceMappingURL=TraceDetails.d.ts.map