import React from 'react';
interface LogTimestampProps {
    timestamp: number | string;
}
export declare const LogTimestamp: React.FC<LogTimestampProps>;
export {};
//# sourceMappingURL=LogTimestamp.d.ts.map