import { PluginModuleResource } from '@perses-dev/plugin-system';
/**
 * Returns the plugin module information from package.json
 */
export declare function getPluginModule(): PluginModuleResource;
//# sourceMappingURL=getPluginModule.d.ts.map