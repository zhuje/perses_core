import { ReactElement } from 'react';
import { LogsTableProps } from './model';
export declare function LogsTableComponent(props: LogsTableProps): ReactElement | null;
//# sourceMappingURL=LogsTableComponent.d.ts.map