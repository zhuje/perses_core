import '@testing-library/jest-dom';
//# sourceMappingURL=setup-tests.d.ts.map