import { PanelPlugin } from '@perses-dev/plugin-system';
import { LogsTableOptions, LogsTableProps } from './model';
export declare const LogsTable: PanelPlugin<LogsTableOptions, LogsTableProps>;
//# sourceMappingURL=LogsTable.d.ts.map