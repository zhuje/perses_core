import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { LogsTableOptions } from './model';
type LogsTableSettingsEditorProps = OptionsEditorProps<LogsTableOptions>;
export declare function LogsTableSettingsEditor(props: LogsTableSettingsEditorProps): ReactElement;
export {};
//# sourceMappingURL=LogsTableSettingsEditor.d.ts.map