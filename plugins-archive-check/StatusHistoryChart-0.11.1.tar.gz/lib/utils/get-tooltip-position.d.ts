import { TooltipComponentOption } from 'echarts';
export declare const getTooltipPosition: TooltipComponentOption['position'];
//# sourceMappingURL=get-tooltip-position.d.ts.map