import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { FC } from 'react';
import { StatusHistoryChartOptions } from './status-history-model';
export type StatusHistoryValueMappingEditorProps = OptionsEditorProps<StatusHistoryChartOptions>;
export declare const StatusHistoryValueMappingEditor: FC<StatusHistoryValueMappingEditorProps>;
//# sourceMappingURL=StatusHistoryValueMappingEditor.d.ts.map