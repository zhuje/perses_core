import { PanelPlugin } from '@perses-dev/plugin-system';
import { StatusHistoryChartOptions } from './status-history-model';
import { StatusHistoryChartPanelProps } from './StatusHistoryPanel';
export declare const StatusHistoryChart: PanelPlugin<StatusHistoryChartOptions, StatusHistoryChartPanelProps>;
//# sourceMappingURL=StatusHistoryChart.d.ts.map