export declare const TOOLTIP_TEXT: {
    resetFlameGraph: string;
    changeColorSheme: string;
    exportData: string;
    showTable: string;
    showFlameGraph: string;
    showBoth: string;
};
//# sourceMappingURL=ui-text.d.ts.map