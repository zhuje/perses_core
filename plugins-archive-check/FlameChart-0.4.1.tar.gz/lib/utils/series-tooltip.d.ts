import { SeriesSample } from './data-model';
export declare function getSeriesTooltip(data: SeriesSample, unit: string, name: string, color: string, divColor: string): string;
//# sourceMappingURL=series-tooltip.d.ts.map