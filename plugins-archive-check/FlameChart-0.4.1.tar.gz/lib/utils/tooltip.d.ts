import { FlameChartSample } from './data-model';
/**
 * Generates a tooltip for the flame chart items.
 */
export declare function generateTooltip(params: FlameChartSample, unit: string | undefined): string;
//# sourceMappingURL=tooltip.d.ts.map