import { ReactElement } from 'react';
export interface SearchBarProps {
    searchValue: string;
    onSearchValueChange: (value: string) => void;
}
export declare function SearchBar(props: SearchBarProps): ReactElement;
//# sourceMappingURL=SearchBar.d.ts.map