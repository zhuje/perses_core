import { ReactElement } from 'react';
import { ProfileData } from '@perses-dev/core';
export interface SeriesChartProps {
    width: number;
    height: number;
    data: ProfileData;
}
export declare function SeriesChart(props: SeriesChartProps): ReactElement;
//# sourceMappingURL=SeriesChart.d.ts.map