import { ReactElement } from 'react';
import { FlameChartOptionsEditorProps } from '../flame-chart-model';
export declare function FlameChartOptionsEditorSettings(props: FlameChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=FlameChartOptionsEditorSettings.d.ts.map