import { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import { PrometheusTimeSeriesQuerySpec } from './time-series-query-model';
export declare const getTimeSeriesData: TimeSeriesQueryPlugin<PrometheusTimeSeriesQuerySpec>['getTimeSeriesData'];
//# sourceMappingURL=get-time-series-data.d.ts.map