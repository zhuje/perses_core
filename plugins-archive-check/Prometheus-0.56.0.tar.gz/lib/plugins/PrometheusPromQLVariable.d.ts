import { VariablePlugin } from '@perses-dev/plugin-system';
import { PrometheusPromQLVariableOptions } from './types';
export declare const PrometheusPromQLVariable: VariablePlugin<PrometheusPromQLVariableOptions>;
//# sourceMappingURL=PrometheusPromQLVariable.d.ts.map