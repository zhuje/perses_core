import { VariablePlugin } from '@perses-dev/plugin-system';
import { PrometheusLabelValuesVariableOptions } from './types';
export declare const PrometheusLabelValuesVariable: VariablePlugin<PrometheusLabelValuesVariableOptions>;
//# sourceMappingURL=PrometheusLabelValuesVariable.d.ts.map