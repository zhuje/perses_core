import { ReactElement } from 'react';
export declare function PrometheusExplorer(): ReactElement;
//# sourceMappingURL=PrometheusExplorer.d.ts.map