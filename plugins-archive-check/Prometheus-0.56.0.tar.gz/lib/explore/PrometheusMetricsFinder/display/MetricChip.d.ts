import { ChipProps } from '@mui/material';
import { ReactElement } from 'react';
export declare function MetricChip({ label, ...props }: ChipProps): ReactElement;
//# sourceMappingURL=MetricChip.d.ts.map