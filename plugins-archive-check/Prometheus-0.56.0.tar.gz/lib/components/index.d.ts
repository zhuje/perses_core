export * from './PromQLEditor';
//# sourceMappingURL=index.d.ts.map