import { ReactElement } from 'react';
import { ReactCodeMirrorProps } from '@uiw/react-codemirror';
export type LogQLEditorProps = Omit<ReactCodeMirrorProps, 'theme' | 'extensions'>;
export declare function LogQLEditor(props: LogQLEditorProps): ReactElement;
//# sourceMappingURL=logql-editor.d.ts.map