import { DatasourcePlugin } from '@perses-dev/plugin-system';
import { LokiClient } from '../../model/loki-client';
import { LokiDatasourceSpec } from './loki-datasource-types';
export declare const LokiDatasource: DatasourcePlugin<LokiDatasourceSpec, LokiClient>;
//# sourceMappingURL=LokiDatasource.d.ts.map