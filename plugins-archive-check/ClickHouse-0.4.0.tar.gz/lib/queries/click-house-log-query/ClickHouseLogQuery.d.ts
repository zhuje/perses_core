import { ClickHouseLogQuerySpec } from './click-house-log-query-types';
import { LogQueryPlugin } from './log-query-plugin-interface';
export declare const ClickHouseLogQuery: LogQueryPlugin<ClickHouseLogQuerySpec>;
//# sourceMappingURL=ClickHouseLogQuery.d.ts.map