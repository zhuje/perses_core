import { ClickHouseLogQuerySpec } from './click-house-log-query-types';
import { LogQueryPlugin } from './log-query-plugin-interface';
export declare const getClickHouseLogData: LogQueryPlugin<ClickHouseLogQuerySpec>['getLogData'];
//# sourceMappingURL=get-click-house-log-data.d.ts.map