export { getPluginModule } from './getPluginModule';
export * from './queries';
export * from './datasources';
//# sourceMappingURL=index.d.ts.map