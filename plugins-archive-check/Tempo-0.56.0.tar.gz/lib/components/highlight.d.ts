export declare const traceQLHighlight: import("@lezer/common").NodePropSource;
//# sourceMappingURL=highlight.d.ts.map