import { TraceQueryPlugin } from '@perses-dev/plugin-system';
import { TempoTraceQuerySpec } from '../../model';
/**
 * The core Tempo TraceQuery plugin for Perses.
 */
export declare const TempoTraceQuery: TraceQueryPlugin<TempoTraceQuerySpec>;
//# sourceMappingURL=TempoTraceQuery.d.ts.map