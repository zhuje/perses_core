import { ReactElement } from 'react';
import { TraceQueryEditorProps } from './query-editor-model';
export declare function TempoTraceQueryEditor(props: TraceQueryEditorProps): ReactElement;
interface LimitSelectProps {
    value: number;
    setValue: (x: number) => void;
}
export declare function LimitSelect(props: LimitSelectProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=TempoTraceQueryEditor.d.ts.map